"""Built-in fix agents (Architecture §8.3).

Each targets one failure type and ships a deterministic fix template. (Fix text
can be LLM-drafted when a key is present, but the templates make the framework
work — and verify — offline.) Generation is the only probabilistic step; the
loop in ``base.FixAgent.run`` verifies every fix deterministically.
"""

from __future__ import annotations

from debugai.agents.base import FixAgent
from debugai.agents.types import (
    FAILED, PENDING_RERUN, VERIFIED, FixCandidate, FixReport, TestCase,
)
from debugai.detectors import (
    AMBIGUOUS_PROMPT, CITATION_FAILURE, CONTEXT_OVERFLOW, ENTITY_GAP, HALLUCINATION,
    PROMPT_BRITTLENESS, RETRIEVAL_FAILURE, SCHEMA_VIOLATION, TOOL_CALL_FAILURE,
)
from debugai.judge import INSTRUCTION_VIOLATION, judge_instructions
from debugai.schema import CaptureRecord


def _first(xs: list[str], n: int) -> list[str]:
    return [x for x in xs[:n] if x]


# --------------------------------------------------------------------------- #
# 1. Prompt Rule Agent — hallucination
# --------------------------------------------------------------------------- #
class PromptRuleAgent(FixAgent):
    name = "Prompt Rule Agent"
    handles = HALLUCINATION

    GROUNDING = (
        "Answer ONLY using the provided context. If the context does not contain "
        "the answer, reply exactly: \"I don't have that information.\" Never invent "
        "names, numbers, dates, clauses, or citations. For every specific claim, the "
        "supporting text must appear in the context."
    )

    def generate_fix(self, diagnosis, record):
        return FixCandidate(
            agent=self.name, failure=self.handles,
            strategy="Add grounding constraints + an out-of-context fallback to the system prompt.",
            rationale="Retrieval succeeded but the output is ungrounded — constrain "
                      "generation to the supplied context.",
            system_prompt_additions=self.GROUNDING,
        )

    def build_test_cases(self, diagnosis, record):
        fab = self._fabricated_entities(record)
        grounded = self._grounded_entities(record)
        tests = [
            TestCase(input=record.user_prompt, must_not_contain=_first(fab, 4),
                     category="original"),
            TestCase(input=record.user_prompt, must_not_contain=_first(fab, 4),
                     category="variance", runs=3),
        ]
        if grounded:
            tests.append(TestCase(input=record.user_prompt,
                                  must_contain=_first(grounded, 1), category="regression"))
        return tests


# --------------------------------------------------------------------------- #
# 2. Knowledge Base Agent — retrieval failure
# --------------------------------------------------------------------------- #
class KnowledgeBaseAgent(FixAgent):
    name = "Knowledge Base Agent"
    handles = RETRIEVAL_FAILURE
    verifiable_by_rerun = False  # real fix is re-chunking/re-embedding the corpus

    GUARD = (
        "If the retrieved context does not address the question, reply exactly: "
        "\"The knowledge base does not contain this information.\" Do not answer "
        "from prior knowledge."
    )

    def generate_fix(self, diagnosis, record):
        sim = ((diagnosis.get("signals") or {}).get("similarity"))
        return FixCandidate(
            agent=self.name, failure=self.handles,
            strategy="Re-chunk source docs entity-aware + add an interim 'not in KB' guard.",
            rationale=f"Mean retrieval similarity {sim} is below threshold — the "
                      "retriever returned irrelevant chunks.",
            system_prompt_additions=self.GUARD,
            notes="Re-chunk the source corpus with an entity-aware strategy and "
                  "re-embed; verify the target document is actually indexed.",
        )

    def build_test_cases(self, diagnosis, record):
        fab = self._fabricated_entities(record)
        return [
            TestCase(input=record.user_prompt, must_not_contain=_first(fab, 4),
                     category="original"),
            TestCase(input=record.user_prompt, must_not_contain=_first(fab, 4),
                     category="variance", runs=3),
        ]


# --------------------------------------------------------------------------- #
# 3. Constraint Agent — prompt brittleness
# --------------------------------------------------------------------------- #
class ConstraintAgent(FixAgent):
    name = "Constraint Agent"
    handles = PROMPT_BRITTLENESS

    TEMPLATE = (
        "Be deterministic and consistent across runs. Follow a fixed output format "
        "and do not vary phrasing, ordering, or structure between identical inputs."
    )

    def generate_fix(self, diagnosis, record):
        return FixCandidate(
            agent=self.name, failure=self.handles,
            strategy="Lower temperature, add an output-format template, and pin behavior with a few-shot example.",
            rationale="Grounding signals are healthy but output variance is high — "
                      "constrain sampling and format.",
            new_temperature=0.2,
            system_prompt_additions=self.TEMPLATE,
            few_shot_examples=[{"input": record.user_prompt, "output": record.llm_output}],
        )

    def build_test_cases(self, diagnosis, record):
        grounded = self._grounded_entities(record)
        mc = _first(grounded, 1)
        return [
            TestCase(input=record.user_prompt, must_contain=mc, category="regression"),
            TestCase(input=record.user_prompt, must_contain=mc, category="variance", runs=3),
        ]


# --------------------------------------------------------------------------- #
# 4. Context Optimizer Agent — context overflow
# --------------------------------------------------------------------------- #
class ContextOptimizerAgent(FixAgent):
    name = "Context Optimizer Agent"
    handles = CONTEXT_OVERFLOW

    def generate_fix(self, diagnosis, record):
        return FixCandidate(
            agent=self.name, failure=self.handles,
            strategy="Reduce to the top-N most relevant chunks and summarize each to fit the window.",
            rationale="The prompt overflows the context window; trim and compress "
                      "the retrieved context.",
            max_chunks=8,
            chunk_char_budget=240,
            notes="Summarize prior conversation history; consider a larger-context model.",
        )

    def build_test_cases(self, diagnosis, record):
        grounded = self._grounded_entities(record)
        return [
            TestCase(input=record.user_prompt, must_contain=_first(grounded, 1),
                     category="regression"),
        ]


# --------------------------------------------------------------------------- #
# 5. Document Patch Agent — entity gap (escalates)
# --------------------------------------------------------------------------- #
class DocumentPatchAgent(FixAgent):
    name = "Document Patch Agent"
    handles = ENTITY_GAP

    def generate_fix(self, diagnosis, record):
        missing = self._fabricated_entities(record)  # entities not in the corpus
        names = ", ".join(_first(missing, 6)) or "the requested entities"
        return FixCandidate(
            agent=self.name, failure=self.handles,
            strategy="Identify missing entities and flag the knowledge-base gap for human review.",
            rationale="Retrieval is healthy but the corpus lacks coverage for these "
                      "entities — content cannot be safely auto-generated.",
            notes=f"Knowledge base needs articles covering: {names}.",
            escalate=True,
        )

    def build_test_cases(self, diagnosis, record):
        return []  # escalated before tests run


# --------------------------------------------------------------------------- #
# 6. Socratic Tutor Agent — instruction_violation (behavioural / pedagogy)
# --------------------------------------------------------------------------- #
class SocraticTutorAgent(FixAgent):
    name = "Socratic Tutor Agent"
    handles = INSTRUCTION_VIOLATION

    RULES = (
        "STRICT Socratic correction — these override any conflicting guidance above:\n"
        "- Do NOT explain the concept or state the answer. Give at most ONE short "
        "clue (one sentence maximum), and only if the student is stuck.\n"
        "- Lead with the question: the turn must centre on exactly ONE short leading "
        "question (exactly one '?') that moves the student one step forward, and must "
        "never restate or reword a question already asked.\n"
        "- Do not open by paraphrasing the student's message.\n"
        "- Keep the whole turn to 1-2 sentences. When unsure, ask rather than explain."
    )

    def generate_fix(self, diagnosis, record):
        ev = ((diagnosis.get("primary") or {}).get("evidence") or {})
        viols = ev.get("violations") or []
        names = "; ".join(v.get("rule", "") for v in viols[:4]) or "Socratic-method rules"
        return FixCandidate(
            agent=self.name, failure=self.handles,
            strategy="Rewrite the system prompt to enforce the violated Socratic rules.",
            rationale=f"The response broke pedagogy rules ({names}); tighten the "
                      "system prompt so the tutor guides instead of answering.",
            system_prompt_additions=self.RULES,
        )

    def build_test_cases(self, diagnosis, record):
        return []  # verified by re-judging (below), not by must_contain checks

    def run(self, diagnosis, record, rerun=None):
        """Judge-based verify loop: rewrite prompt → regenerate → re-judge."""
        candidate = self.generate_fix(diagnosis, record)
        before = (diagnosis.get("primary") or {}).get("confidence")
        report = FixReport(agent=self.name, failure=self.handles, verdict=PENDING_RERUN,
                           candidate=candidate, diff=self._diff(candidate, record),
                           before_confidence=before)
        if rerun is None:
            return report
        applied = self._apply(candidate, record)
        new_output = rerun(applied.system_prompt, record.user_prompt,
                           applied.chunks, applied.temperature) or ""
        jd = judge_instructions(applied.system_prompt, record.user_prompt, new_output)
        report.reverified = True
        report.after_output = new_output
        report.reverified_cleared = jd.healthy
        report.after_diagnosis = {
            "healthy": jd.healthy,
            "primary": None if jd.healthy else {
                "failure": INSTRUCTION_VIOLATION, "confidence": jd.confidence},
        }
        report.verdict = VERIFIED if jd.healthy else FAILED
        return report


# --------------------------------------------------------------------------- #
# 7. Schema Repair Agent — schema_violation
# --------------------------------------------------------------------------- #
class SchemaRepairAgent(FixAgent):
    name = "Schema Repair Agent"
    handles = SCHEMA_VIOLATION

    RULES = (
        "Return ONLY valid JSON matching the requested schema. Do not include "
        "markdown fences, comments, prose, or extra keys. If a required value is "
        "unknown, use null only when the schema permits null; otherwise ask for the "
        "missing input before returning final JSON."
    )

    def generate_fix(self, diagnosis, record):
        ev = ((diagnosis.get("primary") or {}).get("evidence") or {})
        violations = ev.get("violations") or []
        details = "; ".join(violations[:4]) or "schema validation failed"
        return FixCandidate(
            agent=self.name, failure=self.handles,
            strategy="Enable strict structured output and add a schema-repair retry.",
            rationale=f"The response did not satisfy the declared schema ({details}).",
            system_prompt_additions=self.RULES,
            notes="Validate every model response before use; on validation failure, "
                  "retry once with the validation errors and the same schema.",
        )

    def build_test_cases(self, diagnosis, record):
        return []


# --------------------------------------------------------------------------- #
# 8. Tool Contract Agent — tool_call_failure
# --------------------------------------------------------------------------- #
class ToolContractAgent(FixAgent):
    name = "Tool Contract Agent"
    handles = TOOL_CALL_FAILURE
    verifiable_by_rerun = False

    RULES = (
        "Before answering, decide whether a tool is required. If a listed tool is "
        "required, call exactly one allowed tool with valid JSON arguments. Never "
        "invent tool outputs; answer only after incorporating the tool result."
    )

    def generate_fix(self, diagnosis, record):
        ev = ((diagnosis.get("primary") or {}).get("evidence") or {})
        issues = ev.get("issues") or []
        expected = ", ".join(ev.get("expected_tools") or record.tools_expected or [])
        return FixCandidate(
            agent=self.name, failure=self.handles,
            strategy="Tighten tool-selection rules and validate tool arguments before execution.",
            rationale=f"The tool contract failed ({'; '.join(issues[:3]) or 'tool call issue'}).",
            system_prompt_additions=self.RULES,
            notes=f"Allowed tools: {expected or 'none captured'}. Reject malformed JSON "
                  "arguments, return tool errors to the model, and retry with the exact "
                  "validation error.",
        )

    def build_test_cases(self, diagnosis, record):
        return []


# --------------------------------------------------------------------------- #
# 9. Citation Verifier Agent — citation_failure
# --------------------------------------------------------------------------- #
class CitationVerifierAgent(FixAgent):
    name = "Citation Verifier Agent"
    handles = CITATION_FAILURE

    RULES = (
        "Every factual claim that comes from context must cite a retrieved chunk as "
        "[1], [2], etc. Use only citations that correspond to the supplied chunks. "
        "If no chunk supports a claim, remove the claim or say it is not in the context."
    )

    def generate_fix(self, diagnosis, record):
        return FixCandidate(
            agent=self.name, failure=self.handles,
            strategy="Add citation-format rules and reject citations outside the retrieved set.",
            rationale="The response either omitted required citations or cited chunks "
                      "that were not retrieved.",
            system_prompt_additions=self.RULES,
            notes="Run a citation verifier after generation and retry if any citation "
                  "falls outside the retrieved chunk IDs.",
        )

    def build_test_cases(self, diagnosis, record):
        return []


# --------------------------------------------------------------------------- #
# 10. Ambiguity Gate Agent — ambiguous_prompt
# --------------------------------------------------------------------------- #
class AmbiguityGateAgent(FixAgent):
    name = "Ambiguity Gate Agent"
    handles = AMBIGUOUS_PROMPT

    RULES = (
        "If the user request contains unresolved references, missing constraints, "
        "or ambiguous pronouns, ask exactly one concise clarifying question before "
        "attempting a final answer."
    )

    def generate_fix(self, diagnosis, record):
        return FixCandidate(
            agent=self.name, failure=self.handles,
            strategy="Add an ambiguity gate that asks for clarification before answering.",
            rationale="The prompt was underspecified, but the model answered as if the "
                      "missing context were known.",
            system_prompt_additions=self.RULES,
        )

    def build_test_cases(self, diagnosis, record):
        return [TestCase(input=record.user_prompt, must_contain=["?"], category="original")]


BUILTIN_AGENTS = [
    PromptRuleAgent,
    KnowledgeBaseAgent,
    ConstraintAgent,
    ContextOptimizerAgent,
    DocumentPatchAgent,
    SocraticTutorAgent,
    SchemaRepairAgent,
    ToolContractAgent,
    CitationVerifierAgent,
    AmbiguityGateAgent,
]
